package com.example.appdocsach

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AdminActivity : AppCompatActivity() {

    private lateinit var rcvAdminBooks: RecyclerView
    private lateinit var bookList: ArrayList<BookInfo>
    private lateinit var adapter: AdminBookAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val btnLogout: Button = findViewById(R.id.btnLogout)
        val btnAddBook: Button = findViewById(R.id.btnAddBook)
        rcvAdminBooks = findViewById(R.id.rcvAdminBooks)

        bookList = ArrayList()
        adapter = AdminBookAdapter(
            bookList,
            onEdit = { book -> showAddEditDialog(book) },
            onDelete = { book -> showDeleteConfirm(book) }
        )
        rcvAdminBooks.adapter = adapter
        rcvAdminBooks.layoutManager = LinearLayoutManager(this)

        btnAddBook.setOnClickListener { showAddEditDialog(null) }

        btnLogout.setOnClickListener {
            val sharedPref: SharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
            sharedPref.edit().clear().apply()
            val intent = Intent(this, DangNhapActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        loadBooks()
    }

    private fun loadBooks() {
        RetrofitClient.instance.getBooks().enqueue(object : retrofit2.Callback<BookListResponse> {
            override fun onResponse(call: retrofit2.Call<BookListResponse>, response: retrofit2.Response<BookListResponse>) {
                if (response.isSuccessful) {
                    val res = response.body()
                    if (res != null && res.status == "success") {
                        bookList.clear()
                        bookList.addAll(res.data)
                        adapter.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(this@AdminActivity, "Lỗi tải danh sách sách", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: retrofit2.Call<BookListResponse>, t: Throwable) {
                Toast.makeText(this@AdminActivity, "Không kết nối server: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun showAddEditDialog(existingBook: BookInfo?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_edit_book, null)
        val tvTitle: TextView = dialogView.findViewById(R.id.tvDialogTitle)
        val etTenSach: EditText = dialogView.findViewById(R.id.etTenSach)
        val etTacGia: EditText = dialogView.findViewById(R.id.etTacGia)
        val etTomTat: EditText = dialogView.findViewById(R.id.etTomTat)
        val etHinhAnh: EditText = dialogView.findViewById(R.id.etHinhAnh)
        val etYoutubeLink: EditText = dialogView.findViewById(R.id.etYoutubeLink)
        val btnCancel: Button = dialogView.findViewById(R.id.btnCancel)
        val btnSave: Button = dialogView.findViewById(R.id.btnSave)

        // Nếu là Sửa, fill dữ liệu cũ vào
        if (existingBook != null) {
            tvTitle.text = "Sửa sách"
            etTenSach.setText(existingBook.tenSach)
            etTacGia.setText(existingBook.tacGia)
            etTomTat.setText(existingBook.tomTat)
            etHinhAnh.setText(existingBook.hinhAnh ?: "")
            etYoutubeLink.setText(existingBook.youtubeLink ?: "")
        } else {
            tvTitle.text = "Thêm sách mới"
        }

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnSave.setOnClickListener {
            val tenSach = etTenSach.text.toString().trim()
            val tacGia = etTacGia.text.toString().trim()
            val tomTat = etTomTat.text.toString().trim()
            val hinhAnh = etHinhAnh.text.toString().trim().ifEmpty { null }
            val youtubeLink = etYoutubeLink.text.toString().trim().ifEmpty { null }

            if (tenSach.isEmpty() || tacGia.isEmpty() || tomTat.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin bắt buộc (*)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val sachRequest = SachRequest(tenSach, tacGia, hinhAnh, tomTat, youtubeLink, theLoaiId = null)

            if (existingBook == null) {
                // Thêm mới
                RetrofitClient.instance.addBook(sachRequest).enqueue(object : retrofit2.Callback<SingleResponse> {
                    override fun onResponse(call: retrofit2.Call<SingleResponse>, response: retrofit2.Response<SingleResponse>) {
                        if (response.isSuccessful) {
                            Toast.makeText(this@AdminActivity, "Đã thêm sách thành công!", Toast.LENGTH_SHORT).show()
                            dialog.dismiss()
                            loadBooks()
                        } else {
                            Toast.makeText(this@AdminActivity, "Lỗi khi thêm sách", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: retrofit2.Call<SingleResponse>, t: Throwable) {
                        Toast.makeText(this@AdminActivity, "Lỗi kết nối: ${t.message}", Toast.LENGTH_SHORT).show()
                    }
                })
            } else {
                // Sửa
                RetrofitClient.instance.updateBook(existingBook.id, sachRequest).enqueue(object : retrofit2.Callback<SingleResponse> {
                    override fun onResponse(call: retrofit2.Call<SingleResponse>, response: retrofit2.Response<SingleResponse>) {
                        if (response.isSuccessful) {
                            Toast.makeText(this@AdminActivity, "Đã cập nhật sách thành công!", Toast.LENGTH_SHORT).show()
                            dialog.dismiss()
                            loadBooks()
                        } else {
                            Toast.makeText(this@AdminActivity, "Lỗi khi cập nhật sách", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: retrofit2.Call<SingleResponse>, t: Throwable) {
                        Toast.makeText(this@AdminActivity, "Lỗi kết nối: ${t.message}", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }

        dialog.show()
    }

    private fun showDeleteConfirm(book: BookInfo) {
        AlertDialog.Builder(this)
            .setTitle("Xác nhận xóa")
            .setMessage("Bạn có chắc muốn xóa sách \"${book.tenSach}\" không?\nHành động này không thể hoàn tác!")
            .setPositiveButton("Xóa") { _, _ ->
                RetrofitClient.instance.deleteBook(book.id).enqueue(object : retrofit2.Callback<SingleResponse> {
                    override fun onResponse(call: retrofit2.Call<SingleResponse>, response: retrofit2.Response<SingleResponse>) {
                        if (response.isSuccessful) {
                            Toast.makeText(this@AdminActivity, "Đã xóa sách thành công!", Toast.LENGTH_SHORT).show()
                            loadBooks()
                        } else {
                            Toast.makeText(this@AdminActivity, "Lỗi khi xóa sách", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: retrofit2.Call<SingleResponse>, t: Throwable) {
                        Toast.makeText(this@AdminActivity, "Lỗi kết nối: ${t.message}", Toast.LENGTH_SHORT).show()
                    }
                })
            }
            .setNegativeButton("Hủy", null)
            .show()
    }
}
