package com.example.appdocsach

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AdminBookAdapter(
    private val books: List<BookInfo>,
    private val onEdit: (BookInfo) -> Unit,
    private val onDelete: (BookInfo) -> Unit
) : RecyclerView.Adapter<AdminBookAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTenSach: TextView = view.findViewById(R.id.tvTenSach)
        val tvTacGia: TextView = view.findViewById(R.id.tvTacGia)
        val btnEdit: Button = view.findViewById(R.id.btnEdit)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_book, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val book = books[position]
        holder.tvTenSach.text = book.tenSach
        holder.tvTacGia.text = book.tacGia
        holder.btnEdit.setOnClickListener { onEdit(book) }
        holder.btnDelete.setOnClickListener { onDelete(book) }
    }

    override fun getItemCount() = books.size
}
