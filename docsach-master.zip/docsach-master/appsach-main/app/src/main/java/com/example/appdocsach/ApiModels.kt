package com.example.appdocsach

import com.google.gson.annotations.SerializedName

// Models cho Đăng Nhập
data class LoginRequest(
    @SerializedName("TenDangNhap") val tenDangNhap: String,
    @SerializedName("MatKhau") val matKhau: String
)

data class UserInfo(
    val id: Int,
    val tenDangNhap: String,
    val email: String,
    val tenHienThi: String,
    val vaiTro: String,
    val ngayTao: String?
)

data class LoginResponse(
    val status: String,
    val message: String,
    val user: UserInfo?
)

// Models cho Danh Sách Sách
data class BookInfo(
    val id: Int,
    val tenSach: String,
    val tacGia: String,
    val hinhAnh: String?,
    val tomTat: String,
    val youtubeLink: String?,
    val ngayTao: String?,
    val tenTheLoai: String
)

data class BookListResponse(
    val status: String,
    val data: List<BookInfo>
)

// Models cho Bình Luận
data class BinhLuanRequest(
    @SerializedName("NguoiDungId") val nguoiDungId: Int,
    @SerializedName("SachId") val sachId: Int,
    @SerializedName("NoiDung") val noiDung: String
)

data class BinhLuanItem(
    val id: Int,
    val noiDung: String,
    val ngayBinhLuan: String?,
    val nguoiBinhLuan: String
)

data class BinhLuanListResponse(
    val status: String,
    val data: List<BinhLuanItem>
)

data class SingleResponse(
    val status: String,
    val message: String
)

// Models cho Yêu Thích
data class YeuThichRequest(
    @SerializedName("NguoiDungId") val nguoiDungId: Int,
    @SerializedName("SachId") val sachId: Int
)

data class YeuThichCheckResponse(
    val status: String,
    val is_favorite: Boolean
)

data class YeuThichToggleResponse(
    val status: String,
    val message: String,
    val is_favorite: Boolean
)

// Model cho Admin - Thêm/Sửa Sách
data class SachRequest(
    @SerializedName("TenSach") val tenSach: String,
    @SerializedName("TacGia") val tacGia: String,
    @SerializedName("HinhAnh") val hinhAnh: String?,
    @SerializedName("TomTat") val tomTat: String,
    @SerializedName("YoutubeLink") val youtubeLink: String?,
    @SerializedName("TheLoaiId") val theLoaiId: Int?
)
