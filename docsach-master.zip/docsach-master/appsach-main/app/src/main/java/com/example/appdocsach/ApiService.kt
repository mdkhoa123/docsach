package com.example.appdocsach

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface ApiService {
    @POST("/api/login")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @GET("/api/books")
    fun getBooks(): Call<BookListResponse>

    // API Bình luận
    @GET("/api/books/{book_id}/comments")
    fun getComments(@Path("book_id") bookId: Int): Call<BinhLuanListResponse>

    @POST("/api/comments")
    fun postComment(@Body request: BinhLuanRequest): Call<SingleResponse>

    // API Yêu thích
    @GET("/api/favorites/check")
    fun checkFavorite(
        @retrofit2.http.Query("user_id") userId: Int,
        @retrofit2.http.Query("book_id") bookId: Int
    ): Call<YeuThichCheckResponse>

    @POST("/api/favorites/toggle")
    fun toggleFavorite(@Body request: YeuThichRequest): Call<YeuThichToggleResponse>

    @GET("/api/users/{user_id}/favorites")
    fun getUserFavorites(@Path("user_id") userId: Int): Call<BookListResponse>

    // API Admin - CRUD Sách
    @POST("/api/books")
    fun addBook(@Body request: SachRequest): Call<SingleResponse>

    @PUT("/api/books/{book_id}")
    fun updateBook(@Path("book_id") bookId: Int, @Body request: SachRequest): Call<SingleResponse>

    @DELETE("/api/books/{book_id}")
    fun deleteBook(@Path("book_id") bookId: Int): Call<SingleResponse>
}
