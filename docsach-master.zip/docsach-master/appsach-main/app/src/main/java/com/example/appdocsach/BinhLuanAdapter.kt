package com.example.appdocsach

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class BinhLuanAdapter(var dsBinhLuan: ArrayList<BinhLuanItem>) : RecyclerView.Adapter<BinhLuanAdapter.BinhLuanViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BinhLuanViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_binh_luan, parent, false)
        return BinhLuanViewHolder(view)
    }

    override fun onBindViewHolder(holder: BinhLuanViewHolder, position: Int) {
        val binhLuan = dsBinhLuan[position]
        holder.tvNguoiBinhLuan.text = binhLuan.nguoiBinhLuan
        holder.tvNoiDungBinhLuan.text = binhLuan.noiDung

        // Format lại ngày tháng năm giờ phút nếu có
        if (!binhLuan.ngayBinhLuan.isNullOrEmpty()) {
            try {
                // Giả sử server trả về format: "2026-03-14 23:27:47.807"
                val sdfIn = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                val date = sdfIn.parse(binhLuan.ngayBinhLuan)

                val sdfOut = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                holder.tvNgayBinhLuan.text = date?.let { sdfOut.format(it) } ?: binhLuan.ngayBinhLuan
            } catch (e: Exception) {
                holder.tvNgayBinhLuan.text = binhLuan.ngayBinhLuan
            }
        } else {
            holder.tvNgayBinhLuan.text = ""
        }
    }

    override fun getItemCount(): Int {
        return dsBinhLuan.size
    }

    class BinhLuanViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNguoiBinhLuan: TextView = itemView.findViewById(R.id.tvNguoiBinhLuan)
        val tvNgayBinhLuan: TextView = itemView.findViewById(R.id.tvNgayBinhLuan)
        val tvNoiDungBinhLuan: TextView = itemView.findViewById(R.id.tvNoiDungBinhLuan)
    }
}
