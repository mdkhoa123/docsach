package com.example.appdocsach

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChiTietActivity : AppCompatActivity() {

    lateinit var tvYeuThich: TextView
    var isFavorite = false
    
    lateinit var rcvBinhLuan: RecyclerView
    lateinit var adapterBinhLuan: BinhLuanAdapter
    var mangBinhLuan: ArrayList<BinhLuanItem> = ArrayList()
    
    lateinit var edtBinhLuan: EditText
    lateinit var btnGuiBinhLuan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chi_tiet)

        val img: ImageView = findViewById(R.id.imgChiTiet)
        val tvTen: TextView = findViewById(R.id.tvTenChiTiet)
        val tvTacGia: TextView = findViewById(R.id.tvTacGiaChiTiet)
        val tvTomTat: TextView = findViewById(R.id.tvTomTat)
        val tvBack: TextView = findViewById(R.id.tvBack)
        val btnDocSach: TextView = findViewById(R.id.btnDocSach)
        val btnNgheAudio: TextView = findViewById(R.id.btnNgheAudio)
        
        tvYeuThich = findViewById(R.id.btnYeuThich)
        rcvBinhLuan = findViewById(R.id.rcvBinhLuan)
        edtBinhLuan = findViewById(R.id.edtBinhLuan)
        btnGuiBinhLuan = findViewById(R.id.btnGuiBinhLuan)
        val ten = intent.getStringExtra("gui_ten")
        val tacGia = intent.getStringExtra("gui_tacgia")
        val hinh = intent.getIntExtra("gui_hinh", 0)
        val tumTat = intent.getStringExtra("gui_tomtat")
        val youtubeLink = intent.getStringExtra("gui_youtube")
        val bookId = intent.getIntExtra("gui_id", 0)

        // Lấy ID người dùng đang đăng nhập
        val sharedPref: SharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("USER_ID", 0)

        tvTen.text = ten
        tvTacGia.text = tacGia
        tvTomTat.text = tumTat
        img.setImageResource(hinh)
        
        // Thiết lập RecyclerView cho Bình Luận
        adapterBinhLuan = BinhLuanAdapter(mangBinhLuan)
        rcvBinhLuan.adapter = adapterBinhLuan
        rcvBinhLuan.layoutManager = LinearLayoutManager(this)

        // Tải dữ liệu Yêu Thích và Bình Luận khi mở trang
        if (userId > 0 && bookId > 0) {
            checkFavoriteStatus(userId, bookId)
            loadComments(bookId)
        } else {
            Toast.makeText(this, "Lỗi đọc ID sách hoặc ID người dùng", Toast.LENGTH_SHORT).show()
        }

        tvBack.setOnClickListener {
            finish()
        }

        // Sự kiện VÀO mục Yêu Thích
        tvYeuThich.setOnClickListener {
            if (userId <= 0) {
                Toast.makeText(this, "Bạn chưa đăng nhập hoặc phiên hết hạn. Vui lòng đăng nhập lại!", Toast.LENGTH_LONG).show()
            } else if (bookId <= 0) {
                Toast.makeText(this, "Không xác định được sách (bookId=$bookId)", Toast.LENGTH_SHORT).show()
            } else {
                toggleFavorite(userId, bookId)
            }
        }
        
        // Sự kiện gửi BÌNH LUẬN
        btnGuiBinhLuan.setOnClickListener {
            val noiDung = edtBinhLuan.text.toString().trim()
            if (noiDung.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập nội dung bình luận", Toast.LENGTH_SHORT).show()
            } else if (userId > 0 && bookId > 0) {
                sendComment(userId, bookId, noiDung)
            } else {
                Toast.makeText(this, "Bạn cần đăng nhập để bình luận", Toast.LENGTH_SHORT).show()
            }
        }

        btnNgheAudio.setOnClickListener {
            if (youtubeLink != null && youtubeLink.isNotEmpty()) {
                val ytIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(youtubeLink))
                startActivity(ytIntent)
            } else {
                Toast.makeText(this, "Chưa có audio cho sách này!", Toast.LENGTH_SHORT).show()
            }
        }

        btnDocSach.setOnClickListener {
            Toast.makeText(this, "Đang mở truyện: $ten", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, DocSachActivity::class.java)

            intent.putExtra("gui_ten_truyen", ten)

            startActivity(intent)
        }
    }

    // Các hàm gọi API Backend
    private fun checkFavoriteStatus(userId: Int, bookId: Int) {
        RetrofitClient.instance.checkFavorite(userId, bookId).enqueue(object : Callback<YeuThichCheckResponse> {
            override fun onResponse(call: Call<YeuThichCheckResponse>, response: Response<YeuThichCheckResponse>) {
                val res = response.body()
                if (response.isSuccessful && res != null && res.status == "success") {
                    isFavorite = res.is_favorite
                    updateFavoriteUI()
                }
            }
            override fun onFailure(call: Call<YeuThichCheckResponse>, t: Throwable) {}
        })
    }

    private fun toggleFavorite(userId: Int, bookId: Int) {
        val request = YeuThichRequest(userId, bookId)
        RetrofitClient.instance.toggleFavorite(request).enqueue(object : Callback<YeuThichToggleResponse> {
            override fun onResponse(call: Call<YeuThichToggleResponse>, response: Response<YeuThichToggleResponse>) {
                val res = response.body()
                if (response.isSuccessful && res != null && res.status == "success") {
                    isFavorite = res.is_favorite
                    updateFavoriteUI()
                    Toast.makeText(this@ChiTietActivity, res.message, Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<YeuThichToggleResponse>, t: Throwable) {
                Toast.makeText(this@ChiTietActivity, "Lỗi kết nối", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun updateFavoriteUI() {
        if (isFavorite) {
            tvYeuThich.text = "❤️ Đã Yêu Thích"
            tvYeuThich.setTextColor(android.graphics.Color.parseColor("#FF5252"))
        } else {
            tvYeuThich.text = "♡ Yêu Thích"
            tvYeuThich.setTextColor(android.graphics.Color.parseColor("#FFFFFF"))
        }
    }

    private fun loadComments(bookId: Int) {
        RetrofitClient.instance.getComments(bookId).enqueue(object : Callback<BinhLuanListResponse> {
            override fun onResponse(call: Call<BinhLuanListResponse>, response: Response<BinhLuanListResponse>) {
                val res = response.body()
                if (response.isSuccessful && res != null && res.status == "success") {
                    mangBinhLuan.clear()
                    mangBinhLuan.addAll(res.data)
                    adapterBinhLuan.notifyDataSetChanged()
                }
            }
            override fun onFailure(call: Call<BinhLuanListResponse>, t: Throwable) {}
        })
    }

    private fun sendComment(userId: Int, bookId: Int, noiDung: String) {
        val request = BinhLuanRequest(userId, bookId, noiDung)
        RetrofitClient.instance.postComment(request).enqueue(object : Callback<SingleResponse> {
            override fun onResponse(call: Call<SingleResponse>, response: Response<SingleResponse>) {
                val res = response.body()
                if (response.isSuccessful && res != null && res.status == "success") {
                    Toast.makeText(this@ChiTietActivity, "Đăng bình luận thành công", Toast.LENGTH_SHORT).show()
                    edtBinhLuan.setText("") // Xoá ô nhập
                    loadComments(bookId) // Tải lại danh sách ngay lập tức
                }
            }
            override fun onFailure(call: Call<SingleResponse>, t: Throwable) {
                Toast.makeText(this@ChiTietActivity, "Lỗi kết nối", Toast.LENGTH_SHORT).show()
            }
        })
    }
}