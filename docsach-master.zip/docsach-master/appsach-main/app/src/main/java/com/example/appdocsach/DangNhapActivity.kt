package com.example.appdocsach

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DangNhapActivity : AppCompatActivity() {

    lateinit var edtEmail: EditText
    lateinit var edtPass: EditText
    lateinit var btnLogin: Button
    lateinit var tvChuyenDK: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dang_nhap)

        edtEmail = findViewById(R.id.edtEmailDN)
        edtPass = findViewById(R.id.edtPassDN)
        btnLogin = findViewById(R.id.btnDangNhap)
        tvChuyenDK = findViewById(R.id.tvChuyenDangKy)

        tvChuyenDK.setOnClickListener {
            val i = Intent(this, DangKyActivity::class.java)
            startActivity(i)
        }

        btnLogin.setOnClickListener {
            val emailNhap = edtEmail.text.toString().trim()
            val passNhap = edtPass.text.toString().trim()

            if (emailNhap == "" || passNhap == "") {
                Toast.makeText(this, "Nhập thiếu thông tin", Toast.LENGTH_SHORT).show()
            } else {
                val loginRequest = LoginRequest(emailNhap, passNhap)
                RetrofitClient.instance.login(loginRequest).enqueue(object : retrofit2.Callback<LoginResponse> {
                    override fun onResponse(call: retrofit2.Call<LoginResponse>, response: retrofit2.Response<LoginResponse>) {
                        if (response.isSuccessful) {
                            val loginResponse = response.body()
                            if (loginResponse != null && loginResponse.status == "success") {
                                Toast.makeText(this@DangNhapActivity, "Đăng nhập thành công", Toast.LENGTH_SHORT).show()
                                    
                                // Lưu thông tin đăng nhập vào SharedPreferences
                                val sharedPref: SharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
                                val editor = sharedPref.edit()
                                editor.putInt("USER_ID", loginResponse.user?.id ?: 0)
                                editor.putString("USER_NAME", loginResponse.user?.tenHienThi ?: loginResponse.user?.tenDangNhap)
                                editor.putString("USER_LOGIN", loginResponse.user?.tenDangNhap)
                                editor.putString("USER_ROLE", loginResponse.user?.vaiTro ?: "User")
                                editor.apply()

                                val userRole = loginResponse.user?.vaiTro ?: "User"
                                val intent = if (userRole == "Admin") {
                                    Intent(this@DangNhapActivity, AdminActivity::class.java)
                                } else {
                                    Intent(this@DangNhapActivity, MainActivity::class.java).apply {
                                        putExtra("gui_ten_user", loginResponse.user?.tenHienThi ?: loginResponse.user?.tenDangNhap)
                                    }
                                }
                                startActivity(intent)
                                finish()
                            } else {
                                Toast.makeText(this@DangNhapActivity, "Sai tài khoản hoặc mật khẩu!", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            // Xử lý báo lỗi từ server (mã 401)
                            Toast.makeText(this@DangNhapActivity, "Sai tên đăng nhập hoặc mật khẩu", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: retrofit2.Call<LoginResponse>, t: Throwable) {
                        Toast.makeText(this@DangNhapActivity, "Lỗi kết nối Server: ${t.message}", Toast.LENGTH_LONG).show()
                    }
                })
            }
        }
    }
}