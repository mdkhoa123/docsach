package com.example.appdocsach

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var rcvSach: RecyclerView
    lateinit var adapterSach: SachAdapter
    var mangSach: ArrayList<Sach> = ArrayList()
    var mangSachGoc: ArrayList<Sach> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Hiển thị tên user ở header
        val tvXinChao: TextView = findViewById(R.id.tvXinChao)
        val sharedPref: SharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val tenUser = sharedPref.getString("USER_NAME", "Khách")
        tvXinChao.text = "Xin chào, $tenUser"

        // Khởi tạo RecyclerView
        rcvSach = findViewById(R.id.rcvDanhSach)
        adapterSach = SachAdapter(mangSach)
        rcvSach.adapter = adapterSach
        rcvSach.layoutManager = GridLayoutManager(this, 2)

        // Bộ lọc thể loại
        val btnTatCa: android.widget.Button = findViewById(R.id.btnLocTatCa)
        val btnTieuThuyet: android.widget.Button = findViewById(R.id.btnLocTieuThuyet)
        val btnKyNang: android.widget.Button = findViewById(R.id.btnLocKyNang)
        val btnThieuNhi: android.widget.Button = findViewById(R.id.btnLocThieuNhi)
        val btnKinhDien: android.widget.Button = findViewById(R.id.btnLocKinhDien)

        btnTatCa.setOnClickListener { filterBooks(null) }
        btnTieuThuyet.setOnClickListener { filterBooks("Tiểu thuyết") }
        btnKyNang.setOnClickListener { filterBooks("Kỹ năng sống") }
        btnThieuNhi.setOnClickListener { filterBooks("Truyện thiếu nhi") }
        btnKinhDien.setOnClickListener { filterBooks("Văn học kinh điển") }

        // Bottom Navigation
        val navHome: LinearLayout = findViewById(R.id.navHome)
        val navFavorites: LinearLayout = findViewById(R.id.navFavorites)
        val navProfile: LinearLayout = findViewById(R.id.navProfile)
        val navLogout: LinearLayout = findViewById(R.id.navLogout)

        navHome.setOnClickListener { /* Đang ở trang chủ rồi */ }

        navFavorites.setOnClickListener {
            startActivity(Intent(this, YeuThichActivity::class.java))
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        navLogout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Đăng xuất")
                .setMessage("Bạn có chắc muốn đăng xuất không?")
                .setPositiveButton("Đăng xuất") { _, _ ->
                    sharedPref.edit().clear().apply()
                    val intent = Intent(this, DangNhapActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
                .setNegativeButton("Hủy", null)
                .show()
        }

        loadBooks()
    }

    private fun loadBooks() {
        RetrofitClient.instance.getBooks().enqueue(object : retrofit2.Callback<BookListResponse> {
            override fun onResponse(call: retrofit2.Call<BookListResponse>, response: retrofit2.Response<BookListResponse>) {
                if (response.isSuccessful) {
                    val res = response.body()
                    if (res != null && res.status == "success") {
                        mangSachGoc.clear()
                        for (bookItem in res.data) {
                            val hinhResId = when (bookItem.hinhAnh) {
                                "sach1" -> R.drawable.sach1
                                "sach2" -> R.drawable.sach2
                                "sach3" -> R.drawable.sach3
                                "sach4" -> R.drawable.sach4
                                "sach5" -> R.drawable.sach5
                                "sach6" -> R.drawable.sach6
                                else -> R.drawable.sach1
                            }
                            mangSachGoc.add(
                                Sach(bookItem.id, bookItem.tenSach, bookItem.tacGia, hinhResId, bookItem.tomTat, bookItem.youtubeLink ?: "", bookItem.tenTheLoai)
                            )
                        }
                        filterBooks(null)
                    }
                } else {
                    android.widget.Toast.makeText(this@MainActivity, "Lỗi lấy dữ liệu sách", android.widget.Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: retrofit2.Call<BookListResponse>, t: Throwable) {
                android.widget.Toast.makeText(this@MainActivity, "Không kết nối được server: " + t.message, android.widget.Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun filterBooks(theLoai: String?) {
        mangSach.clear()
        if (theLoai == null) {
            mangSach.addAll(mangSachGoc)
        } else {
            mangSach.addAll(mangSachGoc.filter { it.theLoai == theLoai })
        }
        adapterSach.notifyDataSetChanged()
    }
}