package com.example.appdocsach

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val tvBack: TextView = findViewById(R.id.tvBackProfile)
        val tvTenHienThi: TextView = findViewById(R.id.tvProfileTenHienThi)
        val tvTenDangNhap: TextView = findViewById(R.id.tvProfileTenDangNhap)
        val tvVaiTro: TextView = findViewById(R.id.tvProfileVaiTro)
        val btnLogout: Button = findViewById(R.id.btnProfileLogout)

        val sharedPref: SharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val tenHienThi = sharedPref.getString("USER_NAME", "Chưa có tên")
        val tenDangNhap = sharedPref.getString("USER_LOGIN", "Chưa có")
        val vaiTro = sharedPref.getString("USER_ROLE", "User")

        tvTenHienThi.text = tenHienThi
        tvTenDangNhap.text = tenDangNhap
        tvVaiTro.text = vaiTro

        tvBack.setOnClickListener { finish() }

        btnLogout.setOnClickListener {
            sharedPref.edit().clear().apply()
            val intent = Intent(this, DangNhapActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}
