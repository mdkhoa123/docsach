package com.example.appdocsach

import java.io.Serializable

class Sach : Serializable {
    var id: Int = 0
    var tenSach: String = ""
    var tacGia: String = ""
    var hinhAnh: Int = 0
    var tomTat: String = ""
    var youtubeLink: String = ""
    var theLoai: String = ""

    constructor(id: Int, ten: String, tg: String, hinh: Int, tt: String, linkYT: String = "", theLoai: String = "") {
        this.id = id
        this.tenSach = ten
        this.tacGia = tg
        this.hinhAnh = hinh
        this.tomTat = tt
        this.youtubeLink = linkYT
        this.theLoai = theLoai
    }
}