package com.example.appdocsach

import android.content.Context
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class YeuThichActivity : AppCompatActivity() {

    lateinit var rcvYeuThich: RecyclerView
    lateinit var adapterSach: SachAdapter
    var mangSachYeuThich: ArrayList<Sach> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_yeu_thich)

        val tvBack: TextView = findViewById(R.id.tvBackYT)
        tvBack.setOnClickListener { finish() }

        rcvYeuThich = findViewById(R.id.rcvYeuThich)
        adapterSach = SachAdapter(mangSachYeuThich)
        rcvYeuThich.adapter = adapterSach
        rcvYeuThich.layoutManager = GridLayoutManager(this, 2)

        val sharedPref = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("USER_ID", 0)

        if (userId > 0) {
            loadFavoriteBooks(userId)
        } else {
            Toast.makeText(this, "Vui lòng đăng nhập để xem sách yêu thích", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        // Tải lại khi quay lại màn hình này (lỡ họ mới huỷ yêu thích)
        val sharedPref = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("USER_ID", 0)
        if (userId > 0) {
            loadFavoriteBooks(userId)
        }
    }

    private fun loadFavoriteBooks(userId: Int) {
        RetrofitClient.instance.getUserFavorites(userId).enqueue(object : Callback<BookListResponse> {
            override fun onResponse(call: Call<BookListResponse>, response: Response<BookListResponse>) {
                if (response.isSuccessful) {
                    val res = response.body()
                    if (res != null && res.status == "success") {
                        mangSachYeuThich.clear()
                        for (bookItem in res.data) {
                            val hinhResId = when(bookItem.hinhAnh) {
                                "sach1" -> R.drawable.sach1
                                "sach2" -> R.drawable.sach2
                                "sach3" -> R.drawable.sach3
                                "sach4" -> R.drawable.sach4
                                "sach5" -> R.drawable.sach5
                                "sach6" -> R.drawable.sach6
                                else -> R.drawable.sach1 
                            }
                            mangSachYeuThich.add(
                                Sach(
                                    bookItem.id,
                                    bookItem.tenSach,
                                    bookItem.tacGia,
                                    hinhResId,
                                    bookItem.tomTat,
                                    bookItem.youtubeLink ?: "",
                                    bookItem.tenTheLoai
                                )
                            )
                        }
                        adapterSach.notifyDataSetChanged()
                    }
                }
            }
            override fun onFailure(call: Call<BookListResponse>, t: Throwable) {
                Toast.makeText(this@YeuThichActivity, "Lỗi tải sách yêu thích", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
