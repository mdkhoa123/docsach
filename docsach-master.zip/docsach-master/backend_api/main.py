import pyodbc
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

app = FastAPI(title="API App Đọc Sách - SQL Server")

# Chuỗi kết nối SQL Server (được cung cấp bởi người dùng)
# Có thể điều chỉnh ODBC Driver (17, 18, hoặc SQL Server) tuỳ thuộc vào máy
CONNECTION_STRING = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=DESKTOP-9AKF307\\SQLSERVER;DATABASE=doc_sach;UID=sa;PWD=123456789kyno;TrustServerCertificate=yes;"

def get_connection():
    try:
        # Nếu cài Driver 17 báo lỗi, có thể thử đổi thành {SQL Server}
        return pyodbc.connect(CONNECTION_STRING)
    except Exception as e:
        print(f"Lỗi khi kết nối Database: {e}")
        # Thử lại với cơ chế driver cũ hơn nếu ODBC 17 chưa cài
        try:
            fallback_conn_str = "DRIVER={SQL Server};SERVER=DESKTOP-9AKF307\\SQLSERVER;DATABASE=doc_sach;UID=sa;PWD=123456789kyno;TrustServerCertificate=yes;"
            return pyodbc.connect(fallback_conn_str)
        except Exception as e2:
            print(f"Lỗi fallback kết nối: {e2}")
            return None

# ==========================================
# CÁC MODEL DỮ LIỆU ĐẦU VÀO (Pydantic Models)
# ==========================================

class LoginRequest(BaseModel):
    TenDangNhap: str
    MatKhau: str

class RegisterRequest(BaseModel):
    TenDangNhap: str
    MatKhau: str
    Email: str
    TenHienThi: str

class BinhLuanRequest(BaseModel):
    NguoiDungId: int
    SachId: int
    NoiDung: str

class YeuThichRequest(BaseModel):
    NguoiDungId: int
    SachId: int

class SachRequest(BaseModel):
    TenSach: str
    TacGia: str
    HinhAnh: Optional[str] = None
    TomTat: str
    YoutubeLink: Optional[str] = None
    TheLoaiId: Optional[int] = None


# ==========================================
# CÁC API ENDPOINTS
# ==========================================

@app.get("/")
def read_root():
    return {"message": "API App Đọc Sách đang chạy thành công cùng SQL Server!"}

# 1. API ĐĂNG NHẬP
@app.post("/api/login")
def login(request: LoginRequest):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Không kết nối được Cơ sở dữ liệu")
    
    cursor = conn.cursor()
    query = """
        SELECT Id, TenDangNhap, Email, TenHienThi, VaiTro, NgayTao 
        FROM NguoiDung 
        WHERE (TenDangNhap = ? OR Email = ?) AND MatKhau = ?
    """
    cursor.execute(query, request.TenDangNhap, request.TenDangNhap, request.MatKhau)
    user = cursor.fetchone()
    conn.close()

    if user:
        return {
            "status": "success",
            "message": "Đăng nhập thành công",
            "user": {
                "id": user[0],
                "tenDangNhap": user[1],
                "email": user[2],
                "tenHienThi": user[3],
                "vaiTro": user[4],
                "ngayTao": str(user[5]) if user[5] else None
            }
        }
    else:
        raise HTTPException(status_code=401, detail="Sai tên đăng nhập hoặc mật khẩu")


# 2. API ĐĂNG KÝ
@app.post("/api/register")
def register(request: RegisterRequest):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi kết nối CSDL")
    
    cursor = conn.cursor()
    
    # Kiểm tra xem tên đăng nhập đã tồn tại chưa
    cursor.execute("SELECT Id FROM NguoiDung WHERE TenDangNhap = ?", request.TenDangNhap)
    if cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Tên đăng nhập đã tồn tại")
        
    # Thêm người dùng mới
    insert_query = """
        INSERT INTO NguoiDung (TenDangNhap, MatKhau, Email, TenHienThi, VaiTro, NgayTao)
        VALUES (?, ?, ?, ?, N'User', GETDATE())
    """
    try:
        cursor.execute(insert_query, request.TenDangNhap, request.MatKhau, request.Email, request.TenHienThi)
        conn.commit()
    except Exception as e:
        conn.rollback()
        conn.close()
        raise HTTPException(status_code=500, detail=f"Lỗi khi lưu dữ liệu: {e}")
        
    conn.close()
    return {"status": "success", "message": "Đăng ký thành công!"}


# 3. API LẤY DANH SÁCH SÁCH
@app.get("/api/books")
def get_books():
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
        
    cursor = conn.cursor()
    # Lấy thông tin sách và tên thể loại (nếu TheLoaiId được thiết lập)
    query = """
        SELECT s.Id, s.TenSach, s.TacGia, s.HinhAnh, s.TomTat, s.YoutubeLink, s.NgayTao, t.TenTheLoai
        FROM Sach s
        LEFT JOIN TheLoai t ON s.TheLoaiId = t.Id
    """
    cursor.execute(query)
    books = cursor.fetchall()
    conn.close()

    book_list = []
    for r in books:
        book_list.append({
            "id": r[0],
            "tenSach": r[1],
            "tacGia": r[2],
            "hinhAnh": r[3],
            "tomTat": r[4],
            "youtubeLink": r[5],
            "ngayTao": str(r[6]) if r[6] else None,
            "tenTheLoai": r[7] if r[7] else "Khác"
        })
        
    return {"status": "success", "data": book_list}


# 4. API THÊM BÌNH LUẬN
@app.post("/api/comments")
def add_comment(request: BinhLuanRequest):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
        
    cursor = conn.cursor()
    insert_query = """
        INSERT INTO BinhLuan (NguoiDungId, SachId, NoiDung, NgayBinhLuan)
        VALUES (?, ?, ?, GETDATE())
    """
    try:
        cursor.execute(insert_query, request.NguoiDungId, request.SachId, request.NoiDung)
        conn.commit()
    except Exception as e:
        conn.rollback()
        conn.close()
        raise HTTPException(status_code=500, detail=f"Lỗi: {e}")
        
    conn.close()
    return {"status": "success", "message": "Đã thêm bình luận"}


# 5. API LẤY BÌNH LUẬN THEO SÁCH
@app.get("/api/books/{book_id}/comments")
def get_comments(book_id: int):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
        
    cursor = conn.cursor()
    query = """
        SELECT b.Id, b.NoiDung, b.NgayBinhLuan, n.TenHienThi 
        FROM BinhLuan b
        JOIN NguoiDung n ON b.NguoiDungId = n.Id
        WHERE b.SachId = ?
        ORDER BY b.NgayBinhLuan DESC
    """
    cursor.execute(query, book_id)
    comments = cursor.fetchall()
    conn.close()

    comment_list = []
    for c in comments:
        comment_list.append({
            "id": c[0],
            "noiDung": c[1],
            "ngayBinhLuan": str(c[2]) if c[2] else None,
            "nguoiBinhLuan": c[3]
        })
        
    return {"status": "success", "data": comment_list}


# 6. API KIỂM TRA TRẠNG THÁI YÊU THÍCH
@app.get("/api/favorites/check")
def check_favorite(user_id: int, book_id: int):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
        
    cursor = conn.cursor()
    query = "SELECT Id FROM YeuThich WHERE NguoiDungId = ? AND SachId = ?"
    cursor.execute(query, user_id, book_id)
    result = cursor.fetchone()
    conn.close()
    
    return {"status": "success", "is_favorite": result is not None}


# 7. API BẬT/TẮT YÊU THÍCH
@app.post("/api/favorites/toggle")
def toggle_favorite(request: YeuThichRequest):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
        
    cursor = conn.cursor()
    # Kiểm tra xem đã yêu thích chưa
    check_query = "SELECT Id FROM YeuThich WHERE NguoiDungId = ? AND SachId = ?"
    cursor.execute(check_query, request.NguoiDungId, request.SachId)
    existing = cursor.fetchone()
    
    try:
        if existing:
            # Đã có -> Xoá (Bỏ tim)
            delete_query = "DELETE FROM YeuThich WHERE Id = ?"
            cursor.execute(delete_query, existing[0])
            message = "Đã bỏ yêu thích"
            is_favorite = False
        else:
            # Chưa có -> Thêm (Thả tim)
            insert_query = "INSERT INTO YeuThich (NguoiDungId, SachId, NgayYeuThich) VALUES (?, ?, GETDATE())"
            cursor.execute(insert_query, request.NguoiDungId, request.SachId)
            message = "Đã thêm vào mục yêu thích"
            is_favorite = True
            
        conn.commit()
    except Exception as e:
        conn.rollback()
        conn.close()
        raise HTTPException(status_code=500, detail=f"Lỗi: {e}")
        
    conn.close()
    return {"status": "success", "message": message, "is_favorite": is_favorite}


# 8. API LẤY DANH SÁCH SÁCH YÊU THÍCH CỦA USER
@app.get("/api/users/{user_id}/favorites")
def get_user_favorites(user_id: int):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
        
    cursor = conn.cursor()
    query = """
        SELECT s.Id, s.TenSach, s.TacGia, s.HinhAnh, s.TomTat, s.YoutubeLink, s.NgayTao, t.TenTheLoai
        FROM Sach s
        JOIN YeuThich yt ON s.Id = yt.SachId
        LEFT JOIN TheLoai t ON s.TheLoaiId = t.Id
        WHERE yt.NguoiDungId = ?
        ORDER BY yt.NgayYeuThich DESC
    """
    cursor.execute(query, user_id)
    books = cursor.fetchall()
    conn.close()

    book_list = []
    for r in books:
        book_list.append({
            "id": r[0],
            "tenSach": r[1],
            "tacGia": r[2],
            "hinhAnh": r[3],
            "tomTat": r[4],
            "youtubeLink": r[5],
            "ngayTao": str(r[6]) if r[6] else None,
            "tenTheLoai": r[7] if r[7] else "Khác"
        })
        
    return {"status": "success", "data": book_list}


# 9. API THÊM SÁCH MỚI (Admin)
@app.post("/api/books")
def add_book(request: SachRequest):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
    cursor = conn.cursor()
    insert_query = """
        INSERT INTO Sach (TenSach, TacGia, HinhAnh, TomTat, YoutubeLink, TheLoaiId, NgayTao)
        VALUES (?, ?, ?, ?, ?, ?, GETDATE())
    """
    try:
        cursor.execute(insert_query, request.TenSach, request.TacGia, request.HinhAnh, request.TomTat, request.YoutubeLink, request.TheLoaiId)
        conn.commit()
    except Exception as e:
        conn.rollback()
        conn.close()
        raise HTTPException(status_code=500, detail=f"Lỗi: {e}")
    conn.close()
    return {"status": "success", "message": "Đã thêm sách mới"}


# 10. API SỬA SÁCH (Admin)
@app.put("/api/books/{book_id}")
def update_book(book_id: int, request: SachRequest):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
    cursor = conn.cursor()
    update_query = """
        UPDATE Sach
        SET TenSach = ?, TacGia = ?, HinhAnh = ?, TomTat = ?, YoutubeLink = ?, TheLoaiId = ?
        WHERE Id = ?
    """
    try:
        cursor.execute(update_query, request.TenSach, request.TacGia, request.HinhAnh, request.TomTat, request.YoutubeLink, request.TheLoaiId, book_id)
        if cursor.rowcount == 0:
            conn.close()
            raise HTTPException(status_code=404, detail="Không tìm thấy sách")
        conn.commit()
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        conn.close()
        raise HTTPException(status_code=500, detail=f"Lỗi: {e}")
    conn.close()
    return {"status": "success", "message": "Đã cập nhật sách"}


# 11. API XÓA SÁCH (Admin)
@app.delete("/api/books/{book_id}")
def delete_book(book_id: int):
    conn = get_connection()
    if not conn:
        raise HTTPException(status_code=500, detail="Lỗi CSDL")
    cursor = conn.cursor()
    try:
        # Xóa bình luận và yêu thích liên quan trước
        cursor.execute("DELETE FROM BinhLuan WHERE SachId = ?", book_id)
        cursor.execute("DELETE FROM YeuThich WHERE SachId = ?", book_id)
        cursor.execute("DELETE FROM Sach WHERE Id = ?", book_id)
        if cursor.rowcount == 0:
            conn.close()
            raise HTTPException(status_code=404, detail="Không tìm thấy sách")
        conn.commit()
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        conn.close()
        raise HTTPException(status_code=500, detail=f"Lỗi: {e}")
    conn.close()
    return {"status": "success", "message": "Đã xóa sách"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
